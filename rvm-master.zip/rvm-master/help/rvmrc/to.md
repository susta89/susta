    $ rvm rvmrc to ruby-version

Migrate .rvmrc to .ruby-version
