Manage warnings for .rvmrc / Gemfile

    rvm rvmrc warning [check|ignore|reset] [/path/to/file|all.rvmrcs|allGemfiles]
    rvm rvmrc warning [help|list]
